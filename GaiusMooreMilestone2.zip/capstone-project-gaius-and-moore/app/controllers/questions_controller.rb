class QuestionsController < ApplicationController
end
