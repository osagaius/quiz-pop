require 'test_helper'

class GameControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
